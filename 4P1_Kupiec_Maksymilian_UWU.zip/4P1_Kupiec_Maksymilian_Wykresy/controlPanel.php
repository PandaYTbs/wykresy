<?php
    session_start();
    if (!isset($_SESSION["user_id"])) {
        header("Location: index.php");
        exit;
    }

    $host = "localhost";
    $db = "login_app";
    $user = "root";
    $pass = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Błąd połączenia: " . $e->getMessage());
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login App</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
</head>
<body>
    <div id="logoBanerSecond">
        <div id="userPanel">
            <?php if (isset($_SESSION["user"])): ?>
                <span><?= $_SESSION["user"]; ?></span>
                <a href="logout.php">Wyloguj</a>
            <?php else: ?>
                <div id="zalogujTest">
                    <p>Zaloguj</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div id="firstContainer">
        <div id="addingChart">Add Chart</div>
    </div>
    
    <div id="container">
        <div id="temp">
            <img src="temp.php">
            <div id="editButton">Edit</div>
            <div id="deleteButton">Delete</div>
        </div>
    </div>

    <div id="footer">
        <p>© 2026 Maks Kupiec</p>
    </div>
</body>
</html>
<script>
    var liczba = 0;
    var addChart = document.querySelector("#addingChart");

    addChart.addEventListener('click', function() {
        liczba += 1;
        console.log("Kliknięto! Wykres ID:", liczba);

        fetch('addChartBackground.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_wykresu: liczba })
        })
        .then(response => response.text())
        .then(odpowiedz => {
            console.log("Serwer odpowiedział:", odpowiedz);
        });
    });
</script>

<?php 
    if (!empty($_SESSION["user_id"])) {
        $userID = $_SESSION["user_id"];
        echo $userID;

    }
?>