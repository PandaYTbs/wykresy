<?php
session_start();
if (!isset($_SESSION['user_id'])) exit;

$host = "localhost"; $db = "login_app"; $user = "root"; $pass = "";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
} catch (PDOException $e) { exit; }

$id_wykresu = isset($_GET['id_wykresu']) ? (int)$_GET['id_wykresu'] : 0;

// Pobieranie parametrów GET z domyślnymi wartościami (Wymóg cz.1)
$width = isset($_GET['width']) ? (int)$_GET['width'] : 750;
$height = isset($_GET['height']) ? (int)$_GET['height'] : 320;
$total_days = isset($_GET['ilość_dni']) ? (int)$_GET['ilość_dni'] : 28;
$margin = isset($_GET['margin']) ? (int)$_GET['margin'] : 50;

// Pobranie punktów wykresu z bazy danych użytkownika
$stmt = $pdo->prepare("SELECT * FROM temperatures WHERE id_wykresu = ? AND id_uzytkownika = ? ORDER BY dzien_tygodnia ASC");
$stmt->execute([$id_wykresu, $_SESSION['user_id']]);
$rawData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Przebudowanie danych, żeby łatwo odwoływać się po numerze dnia (dzien_tygodnia)
$points = [];
foreach ($rawData as $row) {
    $points[$row['dzien_tygodnia']] = $row;
}

// Tworzenie płótna GD
$image = imagecreatetruecolor($width, $height);
$white = imagecolorallocate($image, 255, 255, 255);
$black = imagecolorallocate($image, 0, 0, 0);
$gray = imagecolorallocate($image, 160, 160, 160);
$light_gray = imagecolorallocate($image, 220, 220, 220);
$blue = imagecolorallocate($image, 0, 102, 204);
$red = imagecolorallocate($image, 255, 51, 51);

imagefill($image, 0, 0, $white);

$graph_width = $width - (2 * $margin);
$graph_height = $height - (2 * $margin);

// Funkcja pomocnicza do rysowania linii przerywanych siatki
function drawGridLine($img, $x1, $y1, $x2, $y2, $color) {
    $style = array($color, $color, IMG_COLOR_TRANSPARENT, IMG_COLOR_TRANSPARENT);
    imagesetstyle($img, $style);
    imageline($img, $x1, $y1, $x2, $y2, IMG_COLOR_STYLED);
}

// 1. OŚ Y - Skala temperatur (od 36.2 do 37.2)
$temp_steps = [37.2, 37.0, 36.8, 36.6, 36.4, 36.2];
foreach ($temp_steps as $t) {
    $y = $margin + ((37.2 - $t) / 1.0) * $graph_height;
    
    // Etykiety tekstowe zgodne ze wzorem profesora
    $label = ($t == 37.0 || $t == 36.2) ? sprintf("%.1f", $t) : sprintf(".%d", ($t * 10) % 10);
    imagestring($image, 3, $margin - 35, $y - 7, $label, $black);
    
    // Czerwona linia na poziomie 37.0, reszta szara przerywana
    if (abs($t - 37.0) < 0.01) {
        imageline($image, $margin, $y, $width - $margin, $y, $red);
    } else {
        drawGridLine($image, $margin, $y, $width - $margin, $y, $light_gray);
    }
}
imagestringup($image, 3, 10, $margin + ($graph_height / 2) + 30, "temperatura", $black);

// 2. OŚ X - Skala dni cyklu
for ($d = 1; $d <= $total_days; $d++) {
    $x = $margin + (($d - 1) / ($total_days - 1)) * $graph_width;
    
    drawGridLine($image, $x, $margin, $x, $height - $margin, $light_gray);
    imageline($image, $x, $height - $margin, $x, $height - $margin + 5, $black);
    imagestring($image, 2, $x - 4, $height - $margin + 8, $d, $black);
}
imageline($image, $margin, $height - $margin, $width - $margin, $height - $margin, $black);
imagestring($image, 3, ($width / 2) - 40, $height - $margin + 25, "dzien pomiaru", $black);

// 3. ŁĄCZENIE KROPEK LINIAMI (Tylko status 'pomiar')
$prev_x = null; $prev_y = null;
for ($d = 1; $d <= $total_days; $d++) {
    $x = $margin + (($d - 1) / ($total_days - 1)) * $graph_width;
    
    if (isset($points[$d]) && $points[$d]['status'] === 'pomiar' && !is_null($points[$d]['temperatura'])) {
        $t_val = (float)$points[$d]['temperatura'];
        $y = $margin + ((37.2 - $t_val) / 1.0) * $graph_height;
        
        if ($prev_x !== null) {
            imagesetthickness($image, 2);
            imageline($image, $prev_x, $prev_y, $x, $y, $blue);
            imagesetthickness($image, 1);
        }
        $prev_x = $x; $prev_y = $y;
    } else {
        $prev_x = null; $prev_y = null; // Przerwanie linii przy braku danych
    }
}

// 4. RYSOWANIE KROPEK (Zgodnie z wymaganiami statusów)
for ($d = 1; $d <= $total_days; $d++) {
    $x = $margin + (($d - 1) / ($total_days - 1)) * $graph_width;
    $status = isset($points[$d]) ? $points[$d]['status'] : 'brak';
    
    if ($status === 'pomiar') {
        $t_val = (float)$points[$d]['temperatura'];
        $y = $margin + ((37.2 - $t_val) / 1.0) * $graph_height;
        imagefilledellipse($image, $x, $y, 8, 8, $blue);
    } elseif ($status === 'choroba') {
        imagefilledellipse($image, $x, $height - $margin, 8, 8, $red);
    } else {
        imagefilledellipse($image, $x, $height - $margin, 8, 8, $gray);
    }
}

header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);