<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    echo "Błąd: Użytkownik nie jest zalogowany.";
    exit;
}

// dane z js
$input = json_decode(file_get_contents('php://input'), true);
$idWykresu = $input['id_wykresu'] ?? null;

if ($idWykresu !== null) {
    
    $userID = $_SESSION["user_id"];

    $host = "localhost";
    $db = "login_app";
    $user = "root";
    $pass = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("INSERT INTO temperatures (id_uzytkownika, id_wykresu) VALUES (:user_id, :id_wykresu)");
        $stmt->execute([
            ':user_id' => $userID,
            ':id_wykresu' => $idWykresu
        ]);

        echo "Sukces! Dodano wykres $idWykresu dla użytkownika o ID $userID";

    } catch (PDOException $e) {
        echo "Błąd bazy danych: " . $e->getMessage();
    }

} else {
    echo "Błąd: Brak ID wykresu.";
}
?>