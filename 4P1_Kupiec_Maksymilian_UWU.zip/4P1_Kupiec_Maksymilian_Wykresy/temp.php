<?php
if (isset($_GET['szerokosc'])) {
    $width = (int)$_GET['szerokosc'];
} else {
    $width = 750;
}

if (isset($_GET['wysokosc'])) {
    $height = (int)$_GET['wysokosc'];
} else {
    $height = 340;
}

if (isset($_GET['ilosc_dni'])) {
    $totalDays = (int)$_GET['ilosc_dni'];
} else {
    $totalDays = 28;
}

if (isset($_GET['marginesy'])) {
    $margin = (int)$_GET['marginesy'];
} else {
    $margin = 60;
}

$image = imagecreatetruecolor($width, $height);

$white      = imagecolorallocate($image, 255, 255, 255);
$black      = imagecolorallocate($image, 0, 0, 0);
$lightGray = imagecolorallocate($image, 210, 210, 210);
$red        = imagecolorallocate($image, 255, 51, 51);

imagefill($image, 0, 0, $white);

$x_start = $margin + 20; 
$graphWidth = $width - $x_start - $margin;
$y_start = $margin;
$graphHeight = $height - (2 * $margin);

function drawDashedGridLine($img, $x1, $y1, $x2, $y2, $color) {
    $style = array($color, $color, IMG_COLOR_TRANSPARENT, IMG_COLOR_TRANSPARENT);
    imagesetstyle($img, $style);
    imageline($img, $x1, $y1, $x2, $y2, IMG_COLOR_STYLED);
}

$temp_steps = [37.2, 37.0, 36.8, 36.6, 36.4, 36.2];

foreach ($temp_steps as $t) {
    $y = $y_start + ((37.2 - $t) / 1.0) * $graphHeight;
    
    if ($t == 37.0 || $t == 36.2) {
        $label = sprintf("%.1f", $t);
    } else {
        $label = sprintf(".%d", ($t * 10) % 10);
    }
    
    imagestring($image, 3, $x_start - 35, $y - 7, $label, $black);
    
    if (abs($t - 37.0) < 0.01) {
        imageline($image, $x_start, $y, $x_start + $graphWidth, $y, $red);
    } else {
        drawDashedGridLine($image, $x_start, $y, $x_start + $graphWidth, $y, $lightGray);
    }
}

imagestringup($image, 3, 10, $y_start + ($graphHeight / 2) + 35, "temperatura", $black);
imageline($image, $x_start, $y_start, $x_start, $y_start + $graphHeight, $black);

for ($d = 1; $d <= $totalDays; $d++) {
    $x = $x_start + (($d - 1) / ($totalDays - 1)) * $graphWidth;
    
    drawDashedGridLine($image, $x, $y_start, $x, $y_start + $graphHeight, $lightGray);
    
    imageline($image, $x, $y_start + $graphHeight, $x, $y_start + $graphHeight + 4, $black);
    
    if ($d >= 10) {
        $offset_x = 6;
    } else {
        $offset_x = 3;
    }
    
    imagestring($image, 2, $x - $offset_x, $y_start + $graphHeight + 8, $d, $black);
}

imageline($image, $x_start, $y_start + $graphHeight, $x_start + $graphWidth, $y_start + $graphHeight, $black);
imagestring($image, 3, $x_start + ($graphWidth / 2) - 45, $y_start + $graphHeight + 25, "dzien pomiaru", $black);


header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>