<?php
session_start();

$host = "localhost";
$db = "login_app";
$user = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Błąd połączenia: " . $e->getMessage());
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = $_POST["emailInput"] ?? '';
    $password = $_POST["passwordInput"] ?? '';

    // REJESTRACJA
    if (isset($_POST["createAccount"])) {

        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
            if (strlen($password) < 8) {
                $message = "Min. 8 znaków";
            } elseif (!preg_match('/[a-z]/', $password)) {
                $message = "Brak małej litery";
            } elseif (!preg_match('/[A-Z]/', $password)) {
                $message = "Brak dużej litery";
            } elseif (!preg_match('/\d/', $password)) {
                $message = "Brak cyfry";
            } else {
                $message = "Hasło nie spełnia wymagań";
            }
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE name = ?");
            $stmt->execute([$name]);

            if ($stmt->rowCount() > 0) {
                $message = "Użytkownik już istnieje";
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare("INSERT INTO users (name, password) VALUES (?, ?)");
                $stmt->execute([$name, $hashedPassword]);

                $message = "Konto utworzone";
            }
        }
    }

    // LOGOWANIE
    if (isset($_POST["loginAccount"])) {

        $stmt = $pdo->prepare("SELECT * FROM users WHERE name = ?");
        $stmt->execute([$name]);

        $user = $stmt->fetch();

        if ($user) {
            if (password_verify($password, $user["password"])) {
                $_SESSION["user"] = $user["name"];
                $_SESSION["user_id"] = $user["id"];
                header("Location: controlPanel.php");
            } else {
                $message = "Złe hasło";
            }
        } else {
            $message = "Użytkownik nie istnieje";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Login App</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>

<?php if (!empty($message)): ?>
<div id="overlay">
    <div class="messageBox"><?= $message ?></div>
</div>
<?php endif; ?>

<div id="logoBaner">
    <div class="createLogin" id="login"><p>Login</p></div>
    <div class="createLogin" id="create"><p>Create Account</p></div>

    <div id="userPanel">
        <?php if (isset($_SESSION["user"])): ?>
            <span><?= $_SESSION["user"]; ?></span>
            <a href="logout.php">Wyloguj</a>
        <?php else: ?>
            <div id="zalogujTest">
                <p>Zaloguj</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div id="container">
    <div id="contentLogin">
        <div id="circleLogo"></div>
        <form method="POST">
            <input type="text" name="emailInput" placeholder="name"><br>
            <input type="password" name="passwordInput" placeholder="password"><br>
            <input type="submit" value="Login" id="LoginInput" name="loginAccount">
            <a href="#">Forgot password</a>
        </form>
    </div>

    <div id="contentCreate">
        <div id="circleLogo"></div>
        <form method="POST">
            <input type="text" name="emailInput" placeholder="name"><br>
            <input type="password" name="passwordInput" placeholder="password"><br>
            <input type="submit" value="Create account" id="createAccount" name="createAccount">
        </form>
    </div>
</div>

<div id="footer">
    <p>© 2026 Maks Kupiec</p>
</div>

</body>
</html>