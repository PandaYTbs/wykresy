<?php
    session_start();
    if (!isset($_SESSION["user_id"])) {
        header("Location: index.php");
        exit;
    }

    $host = "localhost";
    $db = "login_app";
    $user = "root";
    $pass = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Błąd połączenia: " . $e->getMessage());
    }

    if (!empty($_SESSION["user_id"])) {
        $userID = $_SESSION["user_id"];
    }

    $stmt = $pdo->prepare("SELECT id_wykresu FROM temperatures WHERE id_uzytkownika = :user_id");
        $stmt->execute([
            ':user_id' => $userID
        ]);

    $wykresy = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $numberOfCharts = count($wykresy);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login App</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>
    <div id="logoBanerSecond">
        <div id="userPanel">
            <?php if (isset($_SESSION["user"])): ?>
                <span><?= $_SESSION["user"]; ?></span>
                <a href="logout.php">Wyloguj</a>
            <?php else: ?>
                <div id="zalogujTest">
                    <p>Zaloguj</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div id="firstContainer">
        <form id="chartForm">
            <label for="daysInput"></label>
            <input type="number" id="daysInput" min="1" max="31">
            <input type="submit" id="addingChart" value="Add Chart">
        </form>
    </div>
    
    <div id="container">
        <?php foreach ($wykresy as $row): ?>
            <div class="tempBox" id="chart-<?php echo $row['id_wykresu']; ?>">
                <p>Wykres ID: <?php echo $row['id_wykresu']; ?></p>
                <p>User ID: <?php echo $userID; ?></p>
                <img src="temp.php?id_wykresu=<?= $row['id_wykresu']; ?>"> 
                <div class="editButton">Edit</div>
                <div class="deleteButton" data-id="<?php echo $row['id_wykresu']; ?>">Delete</div>
            </div>
        <?php endforeach; ?>
    </div>

    <div id="footer">
        <p>© 2026 Maks Kupiec</p>
    </div>
</body>
</html>
<script>
    var container = document.querySelector("#container");
    container.addEventListener('click', function(event) {
        if (event.target.classList.contains('deleteButton')) {
            var chartId = event.target.getAttribute("data-id");
            var formData = new FormData();
            formData.append('id_wykresu', chartId);
            
            var deleteButton = event.target;

            fetch('deleteChartBackground.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json()) 
            .then(responsed => {                
                if (responsed.status == true) {
                    deleteButton.parentNode.remove();
                } else {
                    console.log("false", responsed.error);
                }
            })
            .catch(error => console.error("Błąd", error));
        }
    });
    

    
    var chartForm = document.querySelector("#chartForm");
    var addingChart = document.querySelector("#addingChart");
    var container = document.querySelector("#container");
    var chartsNumber = "<?php echo $numberOfCharts?>";
    var number = parseInt(chartsNumber);
    
    addingChart.addEventListener('click', function() {
        event.preventDefault();

        var daysValue = document.querySelector("#daysInput").value;
        var formData = new FormData();
        formData.append("ilosc_dni", daysValue);

        fetch('addChartBackground.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(responsed => {
            console.log("Serwer odpowiedział:", responsed);

            var newNumber = responsed.id_wykresu;
            
            var newChart = document.createElement('div');
            newChart.className = 'tempBox';
            newChart.id = 'chart-' + newNumber;
            newChart.innerHTML = `
                <p>Wykres ID: ${newNumber}</p>
                <p>User ID: <?php echo $userID ?></p>
                <img src="temp.php?id_wykresu=${newNumber}&ilosc_dni=${daysValue}">
                <div class="editButton">Edit</div>
                <div class="deleteButton" data-id="${newNumber}">Delete</div>
            `;
            container.appendChild(newChart);
            chartForm.reset();
        });
    });


    
</script>

<?php 

?>