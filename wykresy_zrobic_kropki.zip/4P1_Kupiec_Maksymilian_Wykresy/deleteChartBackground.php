<?php 
    session_start();
    // print_r($_SESSION);
    // echo intVal($_POST['id_wykresu']);

    if (empty($_SESSION["user_id"]) || empty($_POST['id_wykresu'])) {
        echo "error brak danych wykresu czy usera";
        exit;
    }

    $userID = $_SESSION["user_id"];
    $chartID = intVal($_POST['id_wykresu']);

    $host = "localhost";
    $db = "login_app";
    $user = "root";
    $pass = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmtPoints = $pdo->prepare("DELETE FROM measured_points WHERE id_user = :userID AND id_chart = :chartID");
        $stmtPoints->execute([
            ':userID'  => $userID,
            ':chartID' => $chartID
        ]);

        $stmtChart = $pdo->prepare("DELETE FROM temperatures WHERE id_uzytkownika = :userID AND id_wykresu = :chartID");
        $stmtChart->execute([
            ':userID'  => $userID,
            ':chartID' => $chartID
        ]);

        $data = ['status' => true];

        header('Content-Type: application/json');

        exit(json_encode($data));

    } catch (PDOException $e) {
        echo "Błąd bazy danych: " . $e->getMessage();
    }
?>