<?php
    session_start();
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login App</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
</head>
<body>
    <div id="logoBanerSecond">
        <div id="userPanel">
            <?php if (isset($_SESSION["user"])): ?>
                <span><?= $_SESSION["user"]; ?></span>
                <a href="logout.php">Wyloguj</a>
            <?php else: ?>
                <div id="zalogujTest">
                    <p>Zaloguj</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div id="firstContainer">
        <div id="addingChart">Add Chart</div>
    </div>
    
    <div id="container">
        <div id="temp">
            <img src="temp.php">
            <div id="editButton">Edit</div>
            <div id="deleteButton">Delete</div>
        </div>
        <div id="temp">
            <img src="temp.php">
            <div id="editButton">Edit</div>
            <div id="deleteButton">Delete</div>
        </div>
    </div>

    <div id="footer">
        <p>© 2026 Maks Kupiec</p>
    </div>
</body>
</html>