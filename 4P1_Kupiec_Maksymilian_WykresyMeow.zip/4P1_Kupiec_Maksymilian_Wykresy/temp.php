<?php
// Dane do wykresu (x, y)
$data = [
    ['firstXposs' => 50, 'firstYposs' => 150, 'secondYposs' => 100, 'secondXposs' => 50],
    ['firstXposs' => 50, 'firstYposs' => 100, 'secondYposs' => 150, 'secondXposs' => 200],
    ['firstXposs' => 200, 'firstYposs' => 150, 'secondYposs' => 100, 'secondXposs' => 400],
    ['firstXposs' => 400, 'firstYposs' => 100, 'secondYposs' => 150, 'secondXposs' => 550],
    ['firstXposs' => 550, 'firstYposs' => 150, 'secondYposs' => 150, 'secondXposs' => 550],
    ['firstXposs' => 550, 'firstYposs' => 100, 'secondYposs' => 150, 'secondXposs' => 550]
    
];

// Wymiary obrazu
$width = 600;
$height = 250;
$margin = 50;

// Tworzymy obraz
$image = imagecreatetruecolor($width, $height);

// Kolory
$white = imagecolorallocate($image, 255, 255, 255);
$black = imagecolorallocate($image, 0, 0, 0);
$red   = imagecolorallocate($image, 220, 50, 50);

// Tło
imagefill($image, 0, 0, $white);

// Skala
$maxValue = 30;
$barHeight = ($height - 2 * $margin) / 30;
$pointRadius = 6;

// Rysowanie punktów i etykiet
    // Linia pomocnicza pozioma
    imageline($image, $margin, 100, $width - $margin, 100, $black);
    imageline($image, $margin, 150, $width - $margin, 150, $black);

foreach($data as $i => $item) {
    imagefilledellipse($image, $item['firstXposs'], $item['firstYposs'], $pointRadius * 2, $pointRadius * 2, $red);
    imageline($image, $item['firstXposs'], $item['firstYposs'], $item['secondXposs'], $item['secondYposs'], $red);
}

// Wyświetlenie obrazu
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);

?>