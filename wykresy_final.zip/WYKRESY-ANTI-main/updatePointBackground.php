<?php
    session_start();
    header('Content-Type: application/json');

    if (!isset($_SESSION["user_id"])) {
        echo json_encode(["status" => false, "error" => "Brak autoryzacji"]);
        exit;
    }

    $host = "localhost";
    $db = "login_app";
    $user = "root";
    $pass = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo json_encode(["status" => false, "error" => "Błąd bazy danych"]);
        exit;
    }

    $chartId = $_POST['id_wykresu'] ?? null;
    $day = $_POST['dzien'] ?? null;
    $temperature = $_POST['temperatura'] ?? '';
    $status = $_POST['status'] ?? 'brak';
    $userId = $_SESSION["user_id"];

    if (!$chartId || !$day) {
        echo json_encode(["status" => false, "error" => "Brakujące parametry"]);
        exit;
    }

    if ($status === 'pomiar' && $temperature !== '') {
        $tempFloat = (float)$temperature;
        if ($tempFloat < 36.2 || $tempFloat > 37.2) {
            echo json_encode(["status" => false, "error" => "Wartość poza zakresem wykresu (36.2 - 37.2)"]);
            exit;
        }
    }

    if ($status === 'choroba' || $status === 'brak') {
        $temperature = null;
    }

    try {
        $stmt = $pdo->prepare("
            UPDATE measured_points 
            SET temperature = :temp, status = :status 
            WHERE id_chart = :chart_id AND id_user = :user_id AND day_of_month = :day
        ");
        
        $stmt->execute([
            ':temp' => $temperature,
            ':status' => $status,
            ':chart_id' => $chartId,
            ':user_id' => $userId,
            ':day' => $day
        ]);

        echo json_encode(["status" => true]);
    } catch (PDOException $e) {
        echo json_encode(["status" => false, "error" => $e->getMessage()]);
    }
?>