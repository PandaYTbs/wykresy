<?php
    session_start();

    if (empty($_SESSION["user_id"])) {
        exit("Brak autoryzacji");
    }
    $userID = $_SESSION["user_id"];

    if (isset($_GET['id_wykresu'])) {
        $chartID = (int)$_GET['id_wykresu'];
    } else {
        exit("Brak ID wykresu");
    }

    // Pobieranie parametrów z GET z zabezpieczeniem domyślnych wartości
    $width     = isset($_GET['szerokosc']) ? (int)$_GET['szerokosc'] : 750;
    $height    = isset($_GET['wysokosc'])  ? (int)$_GET['wysokosc']  : 340;
    $totalDays = isset($_GET['ilosc_dni']) ? (int)$_GET['ilosc_dni'] : 28;
    $margin    = isset($_GET['marginesy']) ? (int)$_GET['marginesy'] : 60;

    $host = "localhost";
    $db = "login_app";
    $user = "root";
    $pass = "";

    $pointsData = [];
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT day_of_month, temperature, status FROM measured_points WHERE id_chart = :chartID AND id_user = :userID ORDER BY day_of_month ASC");
        $stmt->execute([
            ':chartID' => $chartID,
            ':userID'  => $userID
        ]);
        $pointsData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // W razie błędu bazy zostaje pusta tablica
    }

    $image = imagecreatetruecolor($width, $height);

    $white      = imagecolorallocate($image, 255, 255, 255);
    $black      = imagecolorallocate($image, 0, 0, 0);
    $lightGray  = imagecolorallocate($image, 210, 210, 210);
    $red        = imagecolorallocate($image, 255, 51, 51);
    $dotGray    = imagecolorallocate($image, 150, 150, 150); 
    $blue       = imagecolorallocate($image, 0, 0, 255);

    imagefill($image, 0, 0, $white);

    $x_start = $margin + 20; 
    $graphWidth = $width - $x_start - $margin;
    $y_start = $margin;
    $graphHeight = $height - (2 * $margin);

    function drawDashedGridLine($img, $x1, $y1, $x2, $y2, $color) {
        $style = array($color, $color, IMG_COLOR_TRANSPARENT, IMG_COLOR_TRANSPARENT);
        imagesetstyle($img, $style);
        imageline($img, $x1, $y1, $x2, $y2, IMG_COLOR_STYLED);
    }

    // 1. OŚ Y - Skala temperatur
    $temp_steps = [37.2, 37.0, 36.8, 36.6, 36.4, 36.2];
    foreach ($temp_steps as $t) {
        $y = $y_start + ((37.2 - $t) / 1.0) * $graphHeight;
        
        if ($t == 37.0 || $t == 36.2) {
            $label = sprintf("%.1f", $t);
        } else {
            $label = sprintf(".%d", ($t * 10) % 10);
        }
        
        imagestring($image, 3, $x_start - 35, $y - 7, $label, $black);
        
        if (abs($t - 37.0) < 0.01) {
            imageline($image, $x_start, $y, $x_start + $graphWidth, $y, $red);
        } else {
            drawDashedGridLine($image, $x_start, $y, $x_start + $graphWidth, $y, $lightGray);
        }
    }

    imagestringup($image, 3, 10, $y_start + ($graphHeight / 2) + 35, "temperatura", $black);
    imageline($image, $x_start, $y_start, $x_start, $y_start + $graphHeight, $black);

    $pointsByDay = [];
    foreach ($pointsData as $p) {
        $pointsByDay[(int)$p['day_of_month']] = $p;
    }

    // Dynamiczny krok etykiet osi X chroniący przed zlewaniem tekstu
    $labelStep = 1;
    if ($graphWidth < 300) {
        $labelStep = 5;
    } else if ($graphWidth < 500) {
        $labelStep = 2;
    }

    // 2. OŚ X & RYSOWANIE PUNKTÓW
    for ($d = 1; $d <= $totalDays; $d++) {
        $x = $x_start + (($d - 1) / ($totalDays - 1)) * $graphWidth;
        
        drawDashedGridLine($image, $x, $y_start, $x, $y_start + $graphHeight, $lightGray);
        imageline($image, $x, $y_start + $graphHeight, $x, $y_start + $graphHeight + 4, $black);
        
        if (($d - 1) % $labelStep === 0 || $d == $totalDays) {
            $offset_x = ($d >= 10) ? 6 : 3;
            imagestring($image, 2, $x - $offset_x, $y_start + $graphHeight + 8, $d, $black);
        }

        if (isset($pointsByDay[$d])) {
            $currentPoint = $pointsByDay[$d];
            $y_bottom = $y_start + $graphHeight; 
            
            if ($currentPoint['status'] === 'brak') {
                imagefilledellipse($image, $x, $y_bottom, 6, 6, $dotGray);
            } else if ($currentPoint['status'] === 'choroba') {
                imagefilledellipse($image, $x, $y_bottom, 8, 8, $red);
            } else if ($currentPoint['status'] === 'pomiar' && $currentPoint['temperature'] !== null) {
                $t_val = (float)$currentPoint['temperature'];
                
                // POPRAWIONE: Dodałem brakujący znak $ przed t_val!
                $y = $y_start + ((37.2 - $t_val) / 1.0) * $graphHeight;
                
                if ($d < $totalDays && isset($pointsByDay[$d + 1])) {
                    $nextPoint = $pointsByDay[$d + 1];
                    if ($nextPoint['status'] === 'pomiar' && $nextPoint['temperature'] !== null) {
                        $next_x = $x_start + (($d) / ($totalDays - 1)) * $graphWidth;
                        $next_t_val = (float)$nextPoint['temperature'];
                        $next_y = $y_start + ((37.2 - $next_t_val) / 1.0) * $graphHeight;
                        
                        imagesetthickness($image, 2);
                        imageline($image, $x, $y, $next_x, $next_y, $blue);
                        imagesetthickness($image, 1);
                    }
                }
                imagefilledellipse($image, $x, $y, 8, 8, $blue);
            }
        }
    }

    imageline($image, $x_start, $y_start + $graphHeight, $x_start + $graphWidth, $y_start + $graphHeight, $black);

    // Dynamiczne środkowanie napisu pod osią X
    $axisLabel = "dzien";
    $labelWidth = strlen($axisLabel) * 7; 
    $axisLabelX = $x_start + ($graphWidth / 2) - ($labelWidth / 2);
    imagestring($image, 3, $axisLabelX, $y_start + $graphHeight + 25, $axisLabel, $black);

    header('Content-Type: image/png');
    imagepng($image);
    imagedestroy($image);
?>