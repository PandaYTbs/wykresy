<?php
    session_start();
    if (empty($_SESSION["user_id"])) {
        echo json_encode(["error" => "Brak autoryzacji"]);
        exit;
    }

    $userID = $_SESSION["user_id"];

    if (!empty($_POST["ilosc_dni"])){
        $dayNumber = intVal($_POST["ilosc_dni"]);
    } else {
        $dayNumber = 28;
    }

    $host = "localhost";
    $db = "login_app";
    $user = "root";
    $pass = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT MAX(id_wykresu) as max_id FROM temperatures WHERE id_uzytkownika = :user_id");
        $stmt->execute([':user_id' => $userID]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result['max_id'] !== null) {
            $nextChartID = intval($result['max_id']) + 1;
        } else {
            $nextChartID = 1;
        }

        if (!empty($_POST["nazwa_wykresu"])) {
            $chartName = $_POST["nazwa_wykresu"];
        } else {
            $chartName = "Wykres " . $nextChartID;
        }
        $stmtInsert = $pdo->prepare("INSERT INTO temperatures (id_wykresu, id_uzytkownika, nazwa_wykresu) VALUES (:chart_id, :user_id, :chart_name)");
        $stmtInsert->execute([
            ':chart_id'   => $nextChartID,
            ':user_id'    => $userID,
            ':chart_name' => $chartName
        ]);

        $stmtPoints = $pdo->prepare("INSERT INTO measured_points (id_user, id_chart, day_of_month, temperature, status) VALUES (:id_user, :id_chart, :day, NULL, 'brak')");
        for ($i = 1; $i <= $dayNumber; $i++) {
            $stmtPoints->execute([
                ':id_user'  => $userID,
                ':id_chart' => $nextChartID,
                ':day'      => $i
            ]);
        }

        $stmtSelect = $pdo->prepare("
            SELECT t.id_wykresu, t.id_uzytkownika, m.day_of_month, m.temperature, m.status 
            FROM temperatures t 
            JOIN measured_points m ON m.id_chart = t.id_wykresu
            WHERE t.id_uzytkownika = :user_id AND t.id_wykresu = :chart_id
        ");

        $stmtSelect->execute([
            ':user_id' => $userID,
            ':chart_id' => $nextChartID
        ]);
        
        $fullData = $stmtSelect->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: application/json');
        echo json_encode([
            "id_wykresu" => $nextChartID,
            "data" => $fullData
        ]);

    } catch (PDOException $e) {
        echo json_encode(["error" => $e->getMessage()]);
    }
?>