<?php
session_start();

// 1. Jeśli klient jest niezalogowany, zapamiętujemy żądany wykres i kierujemy na index.php
if (!isset($_SESSION["user_id"])) {
    if (isset($_GET['edit_chart_id'])) {
        $_SESSION['redirect_after_login'] = "controlPanel.php?edit_chart_id=" . (int)$_GET['edit_chart_id'];
    }
    header("Location: index.php");
    exit;
}

$host = "localhost";
$db = "login_app";
$user = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Błąd połączenia: " . $e->getMessage());
}
$userID = $_SESSION["user_id"];

// 2. Obsługa automatycznego wywołania widoku edycji po powrocie z PDF lub logowania
$autoOpenChartID = null;
if (isset($_GET['edit_chart_id'])) {
    $checkID = (int)$_GET['edit_chart_id'];
    
    // POPRAWKA: Zmiana z 'charts' na 'temperatures' oraz dopasowanie kolumn do Twojej bazy
    $stmtCheck = $pdo->prepare("SELECT id_wykresu FROM temperatures WHERE id_wykresu = :cID AND id_uzytkownika = :uID");
    $stmtCheck->execute([':cID' => $checkID, ':uID' => $userID]);
    
    if ($stmtCheck->fetch()) {
        $autoOpenChartID = $checkID;
    } else {
        header("Location: controlPanel.php");
        exit;
    }
}

// Pobieranie listy wykresów użytkownika - poprawione nazwy tabel i kolumn pod phpMyAdmin
$stmt = $pdo->prepare("
    SELECT t.id_wykresu, t.nazwa_wykresu, COUNT(m.id) as ilosc_dni 
    FROM temperatures t
    LEFT JOIN measured_points m ON m.id_chart = t.id_wykresu AND m.id_user = t.id_uzytkownika
    WHERE t.id_uzytkownika = :user_id
    GROUP BY t.id_wykresu, t.nazwa_wykresu
");

$stmt->execute([
    ':user_id' => $userID
]);
$wykresy = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Login App - Panel</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
    <style>
        .hidden { 
            display: none !important; 
        }
        #editView {
            text-align: center; margin: 20px auto; max-width: 800px;
        }
        .backButton { 
            background: #555; color: white; padding: 10px; cursor: pointer; display: inline-block; margin-bottom: 20px; border-radius: 4px; 
        }
        .pdfButton {
            background: #d32f2f; color: white; padding: 0 10px; text-decoration: none; border-radius: 3px; font-weight: bold; display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
        }
        .pdfButton:hover {
            background: #b71c1c;
        }
    </style>
</head>
<body>
    <div id="logoBanerSecond">
        <div id="userPanel">
            <?php if (isset($_SESSION["user"])): ?>
                <span><?= $_SESSION["user"]; ?></span>
                <a href="logout.php">Wyloguj</a>
            <?php else: ?>
                <div id="zalogujTest">
                    <p>Zaloguj</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div id="mainView">
        <div id="firstContainer">
            <form id="chartForm">
                <label for="chartNameInput">Nazwa wykresu:</label>
                <input type="text" id="chartNameInput" required>
                <label for="daysInput">Ilość dni:</label>
                <input type="number" id="daysInput" min="1" max="31" value="28">
                <input type="submit" id="addingChart" value="Add Chart">
            </form>
        </div>
        
        <div id="container">
            <?php foreach ($wykresy as $row): ?>
                <div class="tempBox" id="chart-<?php echo $row['id_wykresu']; ?>">
                <div class="chart-title-top">
                    <?php echo htmlspecialchars($row['nazwa_wykresu']); ?>
                </div>
                <img src="temp.php?id_wykresu=<?php echo $row['id_wykresu']; ?>&ilosc_dni=<?php echo $row['ilosc_dni']; ?>" alt="Wykres">
                <div class="chart-actions">
                    <div class="editButton" 
                        data-id="<?php echo $row['id_wykresu']; ?>" 
                        data-name="<?php echo htmlspecialchars($row['nazwa_wykresu']); ?>" 
                        data-days="<?php echo $row['ilosc_dni']; ?>"
                        data-points="<?php 
                            // Pobieranie punktów - kolumny id_chart oraz id_user zgodnie z Twoją bazą
                            $stmtPoints = $pdo->prepare("SELECT day_of_month, temperature, status FROM measured_points WHERE id_chart = :c_id AND id_user = :u_id ORDER BY day_of_month ASC");
                            $stmtPoints->execute([':c_id' => $row['id_wykresu'], ':u_id' => $userID]);
                            echo htmlspecialchars(json_encode($stmtPoints->fetchAll(PDO::FETCH_ASSOC)), ENT_QUOTES, 'UTF-8');
                        ?>">Edit</div>
                    <a href="generatePdf.php?id_wykresu=<?php echo $row['id_wykresu']; ?>" target="_blank" class="pdfButton">PDF</a>
                    <div class="deleteButton" data-id="<?php echo $row['id_wykresu']; ?>">Delete</div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div id="editView" class="hidden">
        <div class="backButton" id="backToMain">Powrót do panelu</div>
        <h2 id="editChartTitle">Nazwa wykresu</h2>
        <p id="editChartInfo">Wykres ID: X</p>
        <div id="editChartImageContainer"></div>
    </div>

    <div id="pointModal" class="hidden">
        <h4 id="modalTitle">Dzień 1</h4>
        <input type="number" id="modalTemp" step="0.1" min="35.0" max="39.0" placeholder="np. 36.6">
        <button id="btnSaveTemp">Zapisz temperaturę</button>
        <button id="btnStatusChoroba" style="color: brown;">Choroba</button>
        <button id="btnStatusBrak" style="color: gray;">Brak pomiaru</button>
        <button id="btnCancelModal" style="background: #e0e0e0;">Anuluj</button>
    </div>

    <div id="footer">
        <p>© 2026 Maks Kupiec</p>
    </div>
</body>
</html>
<script>
    var currentEditingChartId = null;
    var currentEditingDay = null;

    var mainView = document.querySelector("#mainView");
    var editView = document.querySelector("#editView");
    var container = document.querySelector("#container");

    container.addEventListener('click', function(event) {
        if (event.target.classList.contains('deleteButton')) {
            var chartId = event.target.getAttribute("data-id");
            var formData = new FormData();
            formData.append('id_wykresu', chartId);
            
            var deleteButton = event.target;

            fetch('deleteChartBackground.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json()) 
            .then(responsed => {                
                if (responsed.status == true) {
                    deleteButton.parentNode.parentNode.remove();
                } else {
                    console.log("Błąd usuwania:", responsed.error);
                }
            })
            .catch(error => console.error("Błąd sieci:", error));
        } 
        else if (event.target.classList.contains('editButton')) {
            var chartId = event.target.getAttribute("data-id");
            var chartName = event.target.getAttribute("data-name");
            var chartDays = parseInt(event.target.getAttribute("data-days"));
            
            currentEditingChartId = chartId;

            document.querySelector("#editChartTitle").innerText = chartName;
            document.querySelector("#editChartInfo").innerText = "Wykres ID: " + chartId + " | Ilość dni: " + chartDays;

            var imgContainer = document.querySelector("#editChartImageContainer");
            imgContainer.innerHTML = `<img src="temp.php?id_wykresu=${chartId}&ilosc_dni=${chartDays}" id="chartImg">`;

            renderEditableDots();

            mainView.classList.add("hidden");
            editView.classList.remove("hidden");
        }
    });

    function renderEditableDots() {
        var mainEditBtn = document.querySelector("#chart-" + currentEditingChartId + " .editButton");
        if (!mainEditBtn) return;

        var chartDays = parseInt(mainEditBtn.getAttribute("data-days"));
        var points = JSON.parse(mainEditBtn.getAttribute("data-points") || "[]");
        var imgContainer = document.querySelector("#editChartImageContainer");

        var chartImg = document.querySelector("#chartImg");
        var currentWidth = 750;  
        var currentHeight = 340; 

        if (chartImg && chartImg.src) {
            var widthMatch = chartImg.src.match(/[?&]szerokosc=(\d+)/);
            if (widthMatch) {
                currentWidth = parseInt(widthMatch[1]);
            }
            var heightMatch = chartImg.src.match(/[?&]wysokosc=(\d+)/);
            if (heightMatch) {
                currentHeight = parseInt(heightMatch[1]);
            }
        }

        var oldDots = imgContainer.querySelectorAll(".clickable-dot");
        oldDots.forEach(dot => dot.remove());

        var margin = 60;
        var x_start = margin + 20; 
        var graphWidth = currentWidth - x_start - margin; 
        var y_start = margin; 
        var graphHeight = currentHeight - (2 * margin); 
        var y_bottom = y_start + graphHeight;

        var pointsByDay = {};
        points.forEach(function(p) {
            pointsByDay[parseInt(p.day_of_month)] = p;
        });

        for (let d = 1; d <= chartDays; d++) {
            let posX = x_start + ((d - 1) / (chartDays - 1)) * graphWidth;
            let posY = y_bottom; 

            let dayPoint = pointsByDay[d];
            let dotTemp = "";

            if (dayPoint) {
                if (dayPoint.status === 'brak' || dayPoint.status === 'choroba') {
                    posY = y_bottom;
                } else if (dayPoint.status === 'pomiar' && dayPoint.temperature !== null) {
                    let t_val = parseFloat(dayPoint.temperature);
                    posY = y_start + ((37.2 - t_val) / 1.0) * graphHeight;
                }
                if (dayPoint.temperature) {
                    dotTemp = dayPoint.temperature;
                }
            }

            let dotElement = document.createElement("div");
            dotElement.className = "clickable-dot";
            dotElement.style.left = posX + "px";
            dotElement.style.top = posY + "px";
            dotElement.setAttribute("data-day", d);
            
            dotElement.addEventListener("click", function() {
                currentEditingDay = d;
                document.querySelector("#modalTitle").innerText = "Dzień " + d;
                document.querySelector("#modalTemp").value = dotTemp;
                document.querySelector("#pointModal").classList.remove("hidden");
            });

            imgContainer.appendChild(dotElement);
        }
    }

    document.querySelector("#backToMain").addEventListener('click', function() {
        editView.classList.add("hidden");
        mainView.classList.remove("hidden");
        document.querySelector("#pointModal").classList.add("hidden");

        if (currentEditingChartId) {
            var mainChartBox = document.querySelector("#chart-" + currentEditingChartId);
            if (mainChartBox) {
                var mainImg = mainChartBox.querySelector("img");
                if (mainImg) {
                    mainImg.src = mainImg.src.split('&cache=')[0] + '&cache=' + new Date().getTime();
                }
            }
        }
    });

    document.querySelector("#btnCancelModal").addEventListener("click", function() {
        document.querySelector("#pointModal").classList.add("hidden");
    });

    function updatePointData(temperature, statusValue) {
        var formData = new FormData();
        formData.append('id_wykresu', currentEditingChartId);
        formData.append('dzien', currentEditingDay);
        formData.append('temperatura', temperature);
        formData.append('status', statusValue);

        fetch('updatePointBackground.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === true) {
                document.querySelector("#pointModal").classList.add("hidden");
                
                var img = document.querySelector("#chartImg");
                if (img) {
                    img.src = img.src.split('&cache=')[0] + '&cache=' + new Date().getTime();
                }

                var mainEditBtn = document.querySelector("#chart-" + currentEditingChartId + " .editButton");
                if (mainEditBtn) {
                    var currentPoints = JSON.parse(mainEditBtn.getAttribute("data-points") || "[]");
                    currentPoints = currentPoints.filter(p => parseInt(p.day_of_month) !== currentEditingDay);
                    currentPoints.push({
                        day_of_month: currentEditingDay.toString(),
                        temperature: temperature === '' ? null : temperature,
                        status: statusValue
                    });
                    
                    mainEditBtn.setAttribute("data-points", JSON.stringify(currentPoints));
                }

                renderEditableDots();

            } else {
                alert("Błąd zapisu: " + data.error);
            }
        })
        .catch(error => console.error("Błąd połączenia:", error));
    }

    document.querySelector("#btnSaveTemp").addEventListener("click", function() {
        var tempInput = document.querySelector("#modalTemp").value;
        if (tempInput === "") { 
            alert("Wpisz temperaturę!"); 
            return; 
        }
        var tempFloat = parseFloat(tempInput);
        if (isNaN(tempFloat) || tempFloat < 36.2 || tempFloat > 37.2) {
            alert("Temperatura musi mieścić się w przedziale od 36.2 do 37.2 °C!");
            return;
        }
        updatePointData(tempInput, 'pomiar');
    });

    document.querySelector("#btnStatusChoroba").addEventListener("click", function() {
        updatePointData('', 'choroba');
    });

    document.querySelector("#btnStatusBrak").addEventListener("click", function() {
        updatePointData('', 'brak');
    });
    
    var chartForm = document.querySelector("#chartForm");
    chartForm.addEventListener('submit', function(event) {
        event.preventDefault();

        var daysInput = document.querySelector("#daysInput");
        var nameInput = document.querySelector("#chartNameInput"); 
        var daysValue = parseInt(daysInput.value);
        var chartName = nameInput.value.trim(); 

        if (isNaN(daysValue) || daysValue < 1) { daysValue = 1; daysInput.value = 1; }
        else if (daysValue > 31) { daysValue = 31; daysInput.value = 31; }

        var formData = new FormData();
        formData.append("ilosc_dni", daysValue);
        formData.append("nazwa_wykresu", chartName); 

        fetch('addChartBackground.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(responsed => {
            if (responsed.error) {
                alert("Błąd serwera: " + responsed.error);
                return;
            }

            var newNumber = responsed.id_wykresu;
            var newChart = document.createElement('div');
            newChart.className = 'tempBox';
            newChart.id = 'chart-' + newNumber;
            
            newChart.innerHTML = `
                <div class="chart-title-top">${chartName}</div>
                <img src="temp.php?id_wykresu=${newNumber}&ilosc_dni=${daysValue}" alt="Wykres">
                <div class="chart-actions">
                    <div class="editButton" 
                         data-id="${newNumber}" 
                         data-name="${chartName}" 
                         data-days="${daysValue}" 
                         data-points="[]">Edit</div>
                    <a href="generatePdf.php?id_wykresu=${newNumber}" target="_blank" class="pdfButton">PDF</a>
                    <div class="deleteButton" data-id="${newNumber}">Delete</div>
                </div>
            `;
            container.appendChild(newChart);
            chartForm.reset();
        })
        .catch(error => console.error("Błąd połączenia:", error));
    });

    document.addEventListener("DOMContentLoaded", function() {
        var autoOpenID = "<?php echo $autoOpenChartID; ?>";
        if (autoOpenID && autoOpenID !== "") {
            var targetBtn = document.querySelector("#chart-" + autoOpenID + " .editButton");
            if (targetBtn) {
                targetBtn.click();
            }
        }
    });
</script>