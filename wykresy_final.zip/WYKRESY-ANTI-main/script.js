document.addEventListener("DOMContentLoaded", function() {

    const create = document.querySelector("#create");
    const login = document.querySelector("#login");

    const contentLogin = document.querySelector("#contentLogin");
    const contentCreate = document.querySelector("#contentCreate");
    const zalogujTest = document.querySelector("#zalogujTest");

    function showLogin() {
        create.style.backgroundColor = "#000";
        create.style.color = "#ddd";
        login.style.backgroundColor = "#ddd";
        login.style.color = "#000";

        contentLogin.style.display = "";
        contentCreate.style.display = "none";
    }

    function showCreate() {
        login.style.backgroundColor = "#000";
        login.style.color = "#ddd";
        create.style.backgroundColor = "#ddd";
        create.style.color = "#000";

        contentLogin.style.display = "none";
        contentCreate.style.display = "";
    }

    contentCreate.style.display = "none";

    create.addEventListener("click", showCreate);
    login.addEventListener("click", showLogin);
    zalogujTest.addEventListener("click", showLogin);

    // overlay ukrywanie po wyswietleniu
    const overlay = document.getElementById("overlay");
    if (overlay) {
        setTimeout(() => {
            overlay.style.opacity = "0";
            setTimeout(() => overlay.remove(), 300);
        }, 2000);
    }

});