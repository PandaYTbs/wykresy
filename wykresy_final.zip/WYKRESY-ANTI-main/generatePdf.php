<?php
session_start();

// 1. Ustawienie strefy czasowej wymagane przez profesora
date_default_timezone_set('Europe/Warsaw');

if (empty($_SESSION["user_id"])) {
    exit("Brak autoryzacji");
}
$userID = $_SESSION["user_id"];

if (isset($_GET['id_wykresu'])) {
    $chartID = (int)$_GET['id_wykresu'];
} else {
    exit("Brak ID wykresu");
}

// Pobranie danych o wykresie i punktach do tabeli PDF
$host = "localhost";
$db = "login_app";
$user = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // POPRAWKA BAZODANOWA: Dynamiczne wyliczanie ilosc_dni ze struktury tabeli measured_points
    $stmtChart = $pdo->prepare("
        SELECT t.nazwa_wykresu, 
               (SELECT COUNT(*) FROM measured_points m WHERE m.id_chart = t.id_wykresu AND m.id_user = t.id_uzytkownika) as ilosc_dni 
        FROM temperatures t 
        WHERE t.id_wykresu = :chartID AND t.id_uzytkownika = :userID
    ");
    $stmtChart->execute([':chartID' => $chartID, ':userID' => $userID]);
    $chartInfo = $stmtChart->fetch(PDO::FETCH_ASSOC);

    if (!$chartInfo) {
        exit("Wykres nie istnieje lub brak uprawnień.");
    }

    // Pobranie punktów - kolumny id_chart oraz id_user zgodnie z Twoją tabelą measured_points
    $stmtPoints = $pdo->prepare("SELECT day_of_month, temperature, status FROM measured_points WHERE id_chart = :chartID AND id_user = :userID ORDER BY day_of_month ASC");
    $stmtPoints->execute([':chartID' => $chartID, ':userID' => $userID]);
    $pointsData = $stmtPoints->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    exit("Błąd bazy danych: " . $e->getMessage());
}

// Przygotowanie indeksowanej tablicy dni
$pointsByDay = [];
foreach ($pointsData as $p) {
    $pointsByDay[(int)$p['day_of_month']] = $p;
}

// 2. Ładowanie biblioteki TCPDF
require_once('vendor/autoload.php');

// Tworzenie instancji dokumentu (Format A4, Orientacja Pionowa - Portret)
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

// Dane o twórcy dokumentu
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Maksymilian Kupiec');
$pdf->SetTitle('Raport Wykresu PDF');

// Wyłączenie domyślnych nagłówków i stopek TCPDF, aby zbudować je ręcznie
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Marginesy dokumentu
$pdf->SetMargins(15, 15, 15);
$pdf->SetAutoPageBreak(true, 15);

// Dodanie strony
$pdf->AddPage();

// Nagłówek strony: Data i czas wygenerowania raportu
$pdf->SetFont('helvetica', 'I', 10);
$dateString = "PDF wygenerowano: " . date('d-m-Y H:i:s');
$pdf->Cell(0, 10, $dateString, 0, 1, 'R');

// 3. GENEROWANIE LINKU DO PANELU EDYCJI (Wymaganie profesora dotyczące przekierowania)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$chartLink = $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/controlPanel.php?edit_chart_id=" . $chartID;

// 4. GENEROWANIE WYKRESU JAKO OBRAZEK BEZPOŚREDNIO W PAMIĘCI (zamiast HTTP do temp.php)
$imgWidth = 750;
$imgHeight = 340;
$margin = 60;

$image = imagecreatetruecolor($imgWidth, $imgHeight);
$white      = imagecolorallocate($image, 255, 255, 255);
$black      = imagecolorallocate($image, 0, 0, 0);
$lightGray  = imagecolorallocate($image, 210, 210, 210);
$imgRed     = imagecolorallocate($image, 255, 51, 51);
$dotGray    = imagecolorallocate($image, 150, 150, 150);
$blue       = imagecolorallocate($image, 0, 0, 255);
imagefill($image, 0, 0, $white);

$x_start = $margin + 20;
$graphWidth = $imgWidth - $x_start - $margin;
$y_start = $margin;
$graphHeight = $imgHeight - (2 * $margin);

$totalDays = (int)$chartInfo['ilosc_dni'];
if ($totalDays < 2) $totalDays = 2;

// Funkcja rysowania przerywanych linii siatki
$style = array($lightGray, $lightGray, IMG_COLOR_TRANSPARENT, IMG_COLOR_TRANSPARENT);

// Oś Y - Skala temperatur
$temp_steps = [37.2, 37.0, 36.8, 36.6, 36.4, 36.2];
foreach ($temp_steps as $t) {
    $y = $y_start + ((37.2 - $t) / 1.0) * $graphHeight;
    if ($t == 37.0 || $t == 36.2) {
        $label = sprintf("%.1f", $t);
    } else {
        $label = sprintf(".%d", ($t * 10) % 10);
    }
    imagestring($image, 3, $x_start - 35, $y - 7, $label, $black);
    if (abs($t - 37.0) < 0.01) {
        imageline($image, $x_start, $y, $x_start + $graphWidth, $y, $imgRed);
    } else {
        imagesetstyle($image, $style);
        imageline($image, $x_start, $y, $x_start + $graphWidth, $y, IMG_COLOR_STYLED);
    }
}
imagestringup($image, 3, 10, $y_start + ($graphHeight / 2) + 35, "temperatura", $black);
imageline($image, $x_start, $y_start, $x_start, $y_start + $graphHeight, $black);

// Dynamiczny krok etykiet osi X
$labelStep = 1;
if ($graphWidth < 300) { $labelStep = 5; }
else if ($graphWidth < 500) { $labelStep = 2; }

// Oś X & rysowanie punktów
for ($d = 1; $d <= $totalDays; $d++) {
    $x = $x_start + (($d - 1) / ($totalDays - 1)) * $graphWidth;
    imagesetstyle($image, $style);
    imageline($image, $x, $y_start, $x, $y_start + $graphHeight, IMG_COLOR_STYLED);
    imageline($image, $x, $y_start + $graphHeight, $x, $y_start + $graphHeight + 4, $black);
    if (($d - 1) % $labelStep === 0 || $d == $totalDays) {
        $offset_x = ($d >= 10) ? 6 : 3;
        imagestring($image, 2, $x - $offset_x, $y_start + $graphHeight + 8, $d, $black);
    }
    if (isset($pointsByDay[$d])) {
        $currentPoint = $pointsByDay[$d];
        $y_bottom = $y_start + $graphHeight;
        if ($currentPoint['status'] === 'brak') {
            imagefilledellipse($image, $x, $y_bottom, 6, 6, $dotGray);
        } else if ($currentPoint['status'] === 'choroba') {
            imagefilledellipse($image, $x, $y_bottom, 8, 8, $imgRed);
        } else if ($currentPoint['status'] === 'pomiar' && $currentPoint['temperature'] !== null) {
            $t_val = (float)$currentPoint['temperature'];
            $y = $y_start + ((37.2 - $t_val) / 1.0) * $graphHeight;
            if ($d < $totalDays && isset($pointsByDay[$d + 1])) {
                $nextPoint = $pointsByDay[$d + 1];
                if ($nextPoint['status'] === 'pomiar' && $nextPoint['temperature'] !== null) {
                    $next_x = $x_start + (($d) / ($totalDays - 1)) * $graphWidth;
                    $next_t_val = (float)$nextPoint['temperature'];
                    $next_y = $y_start + ((37.2 - $next_t_val) / 1.0) * $graphHeight;
                    imagesetthickness($image, 2);
                    imageline($image, $x, $y, $next_x, $next_y, $blue);
                    imagesetthickness($image, 1);
                }
            }
            imagefilledellipse($image, $x, $y, 8, 8, $blue);
        }
    }
}
imageline($image, $x_start, $y_start + $graphHeight, $x_start + $graphWidth, $y_start + $graphHeight, $black);
$axisLabel = "dzien";
$labelWidth = strlen($axisLabel) * 7;
$axisLabelX = $x_start + ($graphWidth / 2) - ($labelWidth / 2);
imagestring($image, 3, $axisLabelX, $y_start + $graphHeight + 25, $axisLabel, $black);

// Zapisanie wykresu do pliku tymczasowego
$tmpChartFile = tempnam(sys_get_temp_dir(), 'chart_') . '.png';
imagepng($image, $tmpChartFile);
imagedestroy($image);

$pdf->SetY(25);
$pdf->Image($tmpChartFile, 15, 25, 180, 85, 'PNG', $chartLink, '', true, 150, '', false, false, 0, false, false, false);

// Przesunięcie kursora poniżej wykresu
$pdf->SetY(115);

// Pobieramy aktualne współrzędne, aby ustawić obok siebie Legendę i Tabelę
$yStartContent = $pdf->getY();
$xStartContent = $pdf->getX();

// 5. LEWA STRONA: LEGENDA
$pdf->SetFont('dejavusans', 'B', 12); 
$pdf->Cell(60, 8, 'Legenda:', 0, 1, 'L');
$pdf->SetFont('dejavusans', '', 11);

// Kropka czerwona - Choroba
$pdf->SetY($pdf->getY() + 2);
$currentY = $pdf->getY();
$pdf->SetFillColor(255, 51, 51);
$pdf->Circle($xStartContent + 4, $currentY + 2.5, 2, 0, 360, 'F');
$pdf->SetX($xStartContent + 10);
$pdf->Cell(50, 5, '- choroba', 0, 1, 'L');

// Kropka szara - Brak pomiaru
$pdf->SetY($pdf->getY() + 2);
$currentY = $pdf->getY();
$pdf->SetFillColor(150, 150, 150);
$pdf->Circle($xStartContent + 4, $currentY + 2.5, 2, 0, 360, 'F');
$pdf->SetX($xStartContent + 10);
$pdf->Cell(50, 5, '- brak pomiaru', 0, 1, 'L');


// 6. PRAWA STRONA: TABELA POMIARÓW
$pdf->setXY(95, $yStartContent);

$pdf->SetFont('dejavusans', 'B', 12);
$pdf->Cell(100, 8, 'Pomiary:', 0, 1, 'L');

$pdf->setX(95);
$pdf->SetFont('dejavusans', 'B', 10);
$pdf->SetFillColor(230, 230, 230); 

// Nagłówki kolumn tabeli
$pdf->Cell(25, 6, 'dzień', 1, 0, 'C', true);
$pdf->Cell(35, 6, 'temp.', 1, 1, 'C', true);

$pdf->SetFont('dejavusans', '', 10);

// Generujemy wiersze dla każdego dnia wykresu
for ($d = 1; $d <= $chartInfo['ilosc_dni']; $d++) {
    $pdf->setX(95);
    
    $displayTemp = "-";
    if (isset($pointsByDay[$d])) {
        if ($pointsByDay[$d]['status'] === 'pomiar' && $pointsByDay[$d]['temperature'] !== null) {
            $displayTemp = sprintf("%.2f °C", $pointsByDay[$d]['temperature']);
        } else if ($pointsByDay[$d]['status'] === 'choroba') {
            $displayTemp = "choroba";
        } else if ($pointsByDay[$d]['status'] === 'brak') {
            $displayTemp = "brak pomiaru";
        }
    }
    
    // Rysowanie wierszy danych
    $pdf->Cell(25, 6, $d, 1, 0, 'C');
    $pdf->Cell(35, 6, $displayTemp, 1, 1, 'C');
}

// Czyszczenie bufora i wysłanie pliku PDF do przeglądarki
if (ob_get_level()) {
    ob_end_clean();
}

// Usunięcie pliku tymczasowego z wykresem
if (isset($tmpChartFile) && file_exists($tmpChartFile)) {
    unlink($tmpChartFile);
}

$pdf->Output('wykres_raport_' . $chartID . '.pdf', 'I');
?>